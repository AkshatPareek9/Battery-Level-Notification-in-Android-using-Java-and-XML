package com.example.batterylevelnotification;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.BatteryManager;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    SwitchCompat sw;
    TextView tv;
    ProgressBar pb;
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sw = findViewById(R.id.switchid);
        tv = findViewById(R.id.blsid);
        pb = findViewById(R.id.progressid);

        BatteryManager batteryManager = (BatteryManager) MainActivity.this.getSystemService(BATTERY_SERVICE);
        int batteryStatus = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS);
        int batteryLevel = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        int batteryCurrent = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);

        boolean isCharging = batteryStatus == BatteryManager.BATTERY_STATUS_CHARGING ||
                batteryStatus == BatteryManager.BATTERY_STATUS_FULL;

        String chargingStatus = isCharging ? "Charging Mode" : "Discharging Mode";

        tv.setText("Battery Level: "+batteryLevel+"%\nBattery Status: "+chargingStatus+"\nBattery Current: "+batteryCurrent);

        pb.setProgress(batteryLevel);

        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked)
                {
                    Toast.makeText(MainActivity.this, "Notification Enabled", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(),BatteryReceiver.class);
                    PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this,
                            0,intent,PendingIntent.FLAG_UPDATE_CURRENT);
                    AlarmManager am = (AlarmManager) getApplicationContext().getSystemService(Context.ALARM_SERVICE);
                    am.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis(),AlarmManager.INTERVAL_HOUR/3,pi);
                }
                else{
                    Toast.makeText(MainActivity.this,"Notification Disabled",Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        tv = findViewById(R.id.blsid);
        pb = findViewById(R.id.progressid);

        BatteryManager batteryManager = (BatteryManager) MainActivity.this.getSystemService(BATTERY_SERVICE);
        int batteryStatus = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS);
        int batteryLevel = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        int batteryCurrent = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);

        boolean isCharging = batteryStatus == BatteryManager.BATTERY_STATUS_CHARGING ||
                batteryStatus == BatteryManager.BATTERY_STATUS_FULL;

        String chargingStatus = isCharging ? "Charging Mode" : "Discharging Mode";

        tv.setText("Battery Level: "+batteryLevel+"%\nBattery Status: "+chargingStatus+"\nBattery Current: "+batteryCurrent);

        pb.setProgress(batteryLevel);
    }
}